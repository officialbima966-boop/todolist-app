<?php
// Arahkan ke folder auth
header("Location: auth/login.php");
exit;
?>