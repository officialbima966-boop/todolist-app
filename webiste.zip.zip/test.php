<?php
echo "Test berhasil!";
?>